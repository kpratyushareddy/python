class scrapweb:
	import requests
	import os
	
	from bs4 import BeautifulSoup
	f=open('Tickers1.txt','w+')
	page=requests.get('https://finance.yahoo.com/trending-tickers')
	soup=BeautifulSoup(page.text,'html.parser')

	artist_name_list = soup.find(class_='yfinlist-table W(100%) BdB Bdc($tableBorderGray)')
	g_data = artist_name_list.find_all('a')
	
	os.stat("Tickers")
	for item in g_data:
		if not "react-empty" in item.contents[0]:
			#print(item.contents[0]+"::"+item.get("title"))
	#writing companies into a file:
			f.write(item.contents[0]+"::"+item.get("title")+"\n")
			str1=item.contents[0]
			try:
				os.makedirs(os.path.join("Tickers",str1))#creating directory for each company
			except:
				print("Already Exists")
			#writing data in to html files
			page1=requests.get('https://finance.yahoo.com/quote/'+str1+'?p='+str1)
			soup1=BeautifulSoup(page1.text,'html.parser')
			f1=open("Tickers/"+str1+"/summary.html","w")
			f1.write(str(soup1.encode('utf-8')))
			
			page2=requests.get('https://finance.yahoo.com/quote/'+str1+'/profile?p='+str1)
			soup2=BeautifulSoup(page2.text,'html.parser')
			f2=open("Tickers/"+str1+"/profile.html","w")
			f2.write(str(soup2.encode('utf-8')))
			
			page3=requests.get('https://finance.yahoo.com/quote/'+str1+'/key-statistics?p='+str1)
			soup3=BeautifulSoup(page3.text,'html.parser')
			f3=open("Tickers/"+str1+"/statistics.html","w")
			f3.write(str(soup3.encode('utf-8')))
			
			page4=requests.get('https://finance.yahoo.com/quote/'+str1+'/financials?p='+str1)
			soup4=BeautifulSoup(page4.text,'html.parser')
			f4=open("Tickers/"+str1+"/financials.html","w")
			f4.write(str(soup4.encode('utf-8')))
			
	 
